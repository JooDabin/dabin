import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
/**
 * Write a description of class Freezable here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class tut extends monster implements Freezable
{
    /**
     * Act - do whatever the tut wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int counter;
    public tut(){
        counter = 100;
    }
    public void act() 
    {
       if ( counter <= 0){
            move(3);
        if( Greenfoot.getRandomNumber(100) <10)
        {
            turn(Greenfoot.getRandomNumber(10));
        }
        if(isAtEdge() )
        
            turn(17);
               counter--;
       }
            else
            counter--;
       if(counter == -40){
            counter = 100;
       }
       if( isTouching(lob.class)){
            removeTouching(lob.class);
       }
    }
    public void freeze(int count){
        counter = count;
    }
}
    
       


