import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    counter counter = new counter();
    private int addlobs = 0;
    private int addworms = 0;
    private int addtuts = 0;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(1200, 800, 1); 
        
        while (addlobs< 1)
        {
            addObject( new lob(), Greenfoot.getRandomNumber(1200), Greenfoot.getRandomNumber(800));
            addlobs++;
        }
       
        while (addworms < 30)
        {
            addObject( new worm(), Greenfoot.getRandomNumber(1200), Greenfoot.getRandomNumber(800));
            addworms++;
        }
        
        while (addtuts <1 )
        {
            addObject( new tut(), Greenfoot.getRandomNumber(1200), Greenfoot.getRandomNumber(800));
            addtuts++;
        }
        addObject(new crap(), 100 , 100);
        addObject(counter, 50, 30);
    }
    
    public counter getcounter()
    {
        return counter;
    }
}
