import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)import myWorld.*;
/**
 * Write a description of class crap here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class crap extends monster
{
    private int speed = 2;
    private int newscore = 0;
    private boolean islob = true;
    private int spawnNum = 1;
    private int spawnCounter;
    /**
     * Act - do whatever the crap wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       hitlob();
       movec();
       kill();
       ;
    }
    public void hitlob()
    {
        Actor lob = getOneIntersectingObject(lob.class);
        if(lob !=null)
        {  
            World myWorld = getWorld();
            GameOver gameover = new GameOver();
            myWorld.addObject(gameover, myWorld.getWidth()/2, myWorld.getHeight()/2);
            myWorld.removeObject(this);
        }
    }
    public void kill(){
        Actor worm;
        worm = getOneObjectAtOffset(0,0,worm.class);
        if(worm != null) {
          World myWorld= getWorld();
          myWorld.removeObject(worm);
          MyWorld MyWorld = (MyWorld)myWorld;
          counter counter = MyWorld.getcounter();
          counter.addScore();
            
        }
        
    }
   public void plusscore()
    {
        if((newscore % 100 == 0 && newscore != 0)&&islob){
            for(int i = 0;i<spawnNum;i++){
            	World myworld;
            	myworld = getWorld();
           	 	myworld.addObject( new lob(), Greenfoot.getRandomNumber(1200), Greenfoot.getRandomNumber(800));
            	islob = false;
       		}
			spawnNum++;
        }
         if(newscore % 100 == 10){
            islob = true;
        }
    }
    public void addNewWorm()
    {
        if ( spawnCounter == 1 )
        {
            getWorld().addObject( new worm(), Greenfoot.getRandomNumber(520), Greenfoot.getRandomNumber(520));
            spawnCounter = 0;
        }
    }
     public void movec() 
    {
        // Add your action code here.
        int xpos = getX();
        int ypos = getY();
		
        
        if(Greenfoot.isKeyDown("up")) {
            setRotation(270);
            ypos -= speed;
        }  
        if(Greenfoot.isKeyDown("down")) {
            setRotation(90);
            ypos += speed;
        }
        if(Greenfoot.isKeyDown("left")) {
            setRotation(180);
            xpos -= speed;
        }
        if(Greenfoot.isKeyDown("right")) {
            setRotation(0);
            xpos += speed;
        }
        setLocation(xpos, ypos); //Add your action code here
        // Add your action code here.
    }
}