public interface Freezable{
    public void freeze(int count);
}